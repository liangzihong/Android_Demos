<img src="/app/src/main/res/mipmap-hdpi/ic_meizhi_150602.png" width="128" height="128" /> <img src="/app/src/main/res/mipmap-hdpi/ic_meizhi_150619.png" width="128" height="128" />

**每天自动更新一张精选妹纸图、一个小视频、一系列精选程序猿干货（周末不更新）。数据来自代码家的干货网站：http://gank.io**

Material Design,  RxJava & Retrofit...

<a href="http://www.coolapk.com/apk/me.drakeet.meizhi" target="_blank">
<img src="http://image.coolapk.com/apk_logo/2016/0108/12202_1452248424_4592.png" width="64" height="64">
</a>

下载：http://www.coolapk.com/apk/me.drakeet.meizhi

v2.5.6（2.06MB）
* 修复 缓存机制问题；
* 一些代码上的优化;

v2.4.8
* 改变 "午餐"提醒时间为12:11:38；

v2.3.9
* 新增 App 干货频道/分类；
* 新增 主页菜单中对于中午通知提醒的开关；

v2.3.1
* 大幅 提升干货页面上下滑动的顺滑体验；
* 更新 每日提醒功能，做到更稳健和极低耗电；

v2.2.8（1.9.2MB）
* 新增 妹纸图页面直接分享图片功能；
* 新增 妹纸图页面直接保存图片菜单按钮；
* 更改 主页浮动按钮的图标为 GitHub 小猫；
* 新增 主页浮动按钮打开最新的干货页面；

v2.1 (1.91MB)  
* 新增 浏览器页面右上角的刷新页面、复制链接菜单；
* 优化 视频播放体验；
* 新增 点击主页卡片的文字打开干货页面；  
* 新增 干货视频自动横屏播放； 
* 新增 打开 Android 等干货条目页面；  
* 新增 web 页面标题跑马灯、渐变切换动画效果；
* 新增 登录和缓存 GitHub 帐号功能；

<img src="/screenshots/s0.png" alt="screenshot" title="screenshot" width="270" height="486" />   <img src="/screenshots/s6.png" alt="screenshot" title="screenshot" width="270" height="486" />

<img src="/screenshots/s7.jpg" alt="screenshot" title="screenshot" width="270" height="486" />   <img src="/screenshots/s5.png" alt="screenshot" title="screenshot" width="270" height="486" />

<img src="/screenshots/s8.png" alt="screenshot" title="screenshot" width="270" height="486" />   <img src="/screenshots/s9.png" alt="screenshot" title="screenshot" width="270" height="486" />

### Contributors

[drakeet](https://github.com/drakeet) [junyuecao](https://github.com/junyuecao) [echodjb](https://github.com/echodjb) [iamwent](https://github.com/iamwent) [代码家](https://github.com/daimajia) [linroid](https://github.com/linroid) [SharerMax](https://github.com/SharerMax) [XieQingShan](https://github.com/XieQingShan) [tankcong](https://github.com/tankcong) [zeng1990](https://github.com/zeng1990)

### 特别鸣谢

[XiNGRZ](https://github.com/xingrz) [fython](https://github.com/fython)

### About me

I am a student in China, I love reading pure literature, love Japanese culture and Hongkong music. At the same time, I am also obsessed with writing code. If you have any questions or want to make friends with me, you can write to me: drakeet.me@gmail.com

In addition, my blog: http://drakeet.me

If you like my open source projects, you can follow me: https://github.com/drakeet

#### LICENSE

源代码在 GPL v3 协议下发布, 使用前, 请确保你了解这个协议!   
如有特殊协议方面的请求, 可以与我沟通: drakeet.me@gmail.com

=======

    GNU General Public Licence (GPL)  
    GPL 保证了所有开发者的权利， 
    同时为使用者提供了足够的复制，分发，修改的权利： 
    
    可自由复制  
    你可以将软件复制到你的电脑，你客户的电脑，或者任何地方。复制份数没有任何限制。 
    可自由分发  
    在你的网站提供下载，拷贝到U盘送人，或者将源代码打印出来从窗户扔出去（环保起见，请别这样做）。  
    可以用来盈利
    你可以在分发软件的时候收费，但你必须在收费前向你的客户提供该软件的 GNU GPL  
    许可协议，以便让他们知道，他们可以从别的渠道免费得到这份软件，以及你收费的理由。  
    可自由修改  
    如果你想添加或删除某个功能，没问题，如果你想在别的项目中使用部分代码，  
    也没问题，唯一的要求是，使用了这段代码的项目也必须使用 GPL 协议。  
      
    需要注意的是，分发的时候，需要明确提供源代码和二进制文件，  
    另外，用于某些程序的某些协议有一些问题和限制，  
    你可以看一下 @PierreJoye 写的 Practical Guide to GPL Compliance 一文。  
      
    使用 GPL 协议，你必须在源代码代码中包含相应信息，以及协议本身。  
